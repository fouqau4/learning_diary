#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct s 
{
	int top;
	int bottom;
} suit;

int main( int argc, char* argv[] )
{
	FILE *outfile, *top, *bottom, *suits;

	if( argc != 6 )
	{
		puts("please follow the format below : ");
		puts("./createBadSuits outFileName topFileName bottomFileName suitsFileName num");
		exit(1);
	}
	printf("%s %s %s %s %s %s \n", argv[0], argv[1], argv[2], argv[3], argv[4], argv[5] );	
	if( ( top = fopen( argv[2], "r" ) ) == NULL )
	{
		printf("\'%s\' is not existed.", argv[2] );
		exit(1);
	}
	if( ( bottom = fopen( argv[3], "r" ) ) == NULL )
        {
                printf("\'%s\' is not existed.", argv[3] );
                exit(1);
        }
	if( ( suits = fopen( argv[4], "r" ) ) == NULL )
        {
                printf("\'%s\' is not existed.", argv[4] );
                exit(1);
        }
	suit temp_suit_a[1000];		
	memset( temp_suit_a, 0, sizeof( temp_suit_a ) );
	int suitsNum = 0;
	while( fscanf( suits, "%d_%d", &temp_suit_a[suitsNum].top, &temp_suit_a[suitsNum].bottom ) == 2 )
	{
//		printf("%d_%d\n", temp_suit_a[temp_i].top, temp_suit_a[temp_i].bottom );
		suitsNum++;
	}
	printf("[ %s : %d ]\n", argv[4], suitsNum );
	fclose( suits );
	
	int tops[1000], bottoms[1000];
	int topsNum = 0;
	while( fscanf( top, "%d", &tops[topsNum]  ) == 1 )
	{
//		printf("top : %d\n", tops[temp_i] );
		topsNum++;
	}
	printf("[ %s : %d ]\n", argv[2], topsNum );
	fclose( top );
	int bottomsNum = 0;
	while( fscanf( bottom, "%d", &bottoms[bottomsNum] ) == 1 )
	{
//		printf("bottom : %d\n", bottoms[temp_i] );
		bottomsNum++;
	}
	printf("[ %s : %d ]\n", argv[3], bottomsNum );
	fclose( bottom );	

	int temp_i = 2 * atoi( argv[5] ), temp_i1;
	suit out_suits[temp_i];
	memset( out_suits, 0, sizeof( out_suits ) );
	suit temp_suit;
	for( temp_i1 = 0; temp_i1 < temp_i ; temp_i1++ )
	{
		out_suits[temp_i1].top = rand() % topsNum + 1;
		out_suits[temp_i1].bottom = rand() % bottomsNum + 1;		
	}
	
	if( ( outfile = fopen( argv[1], "w" ) ) == NULL )
	{
		printf("fail to create \'%s\' \n", argv[1] );
		exit(1);
	}
	int temp_i2 = 0;
	for( temp_i = 0 ; temp_i < 2 * atoi( argv[5] ) ; temp_i++ )
	{
		for( temp_i1 = 0 ; temp_i1 < suitsNum ; temp_i1++ )
		{
			if( out_suits[temp_i].top == temp_suit_a[temp_i1].top && out_suits[temp_i].bottom == temp_suit_a[temp_i1].bottom )
			{
				goto next;
			}
		}
		fprintf( outfile, "%d_%d\n", out_suits[temp_i].top, out_suits[temp_i].bottom );
		if( ++temp_i2 == atoi( argv[5] ) )
			break;
		next:;
	}
	fclose( outfile );
	puts("finish!!");
	return 0;
}
